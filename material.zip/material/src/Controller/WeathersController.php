<?php
namespace Drupal\material\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Component\Serialization\Json;
use GuzzleHttp\Psr7\ServerRequest;

/**
 * Provides route responses for the Example module.
 */
class WeathersController extends ControllerBase {


  /**
   * Returns a simple page for weather.
   *
   * @return array
   *   A simple renderable array.
   */
  public function getWeather() {


            #POST METHOD
            // $client = \Drupal::httpClient();
            // $request = $client->post('http://demo.ckan.org/api/3/action/group_list', [
            //   'json' => [
            //     'id'=> 'data-explorer'
            //   ]
            // ]);
            // $response = json_decode($request->getBody())

            #GET Method
            // $client = \Drupal::httpClient();
            // $request = $client->get('api.openweathermap.org/data/2.5/weather?q=New Delhi&appid=2392ca44d17ee8695434d6a0c2bc15f2', [
            //   // 'auth' => ['username','password']
            // ]);


            #Working
            // $client = \Drupal::httpClient();
            // $request = $client->request('GET', 'api.openweathermap.org/data/2.5/weather?q=New Delhi&appid=2392ca44d17ee8695434d6a0c2bc15f2');
            // $response = $request->getBody();
            // $weatherData = Json::decode($response);

            
            $weatherData = [
                'coord' => [
                        'lon' => 77.2311,
                        'lat' => 28.6128
                ],
            
                'weather' => [
                        '0' => 
                            [
                                'id' => 721,
                                'main' => 'Haze',
                                'description' => 'haze',
                                'icon' => '50d',
                            ]
            
                            ],
            
                'base' => 'stations',
                'main' => 
                    [
                        'temp' => 306.24,
                        'feels_like' => 313.24,
                        'temp_min' => 306.24,
                        'temp_max' => 306.24,
                        'pressure' => 1007,
                        'humidity' => 62,
                    ],
            
                'visibility' => 5000,
                'wind' =>
                    [
                        'speed' => 4.63,
                        'deg' => 120
                    ],
            
                'clouds' =>
                    [
                        'all' => 40
                    ],
            
                'dt' => 1632819693,
                'sys' => 
                    [
                        'type' => 1,
                        'id' => 9165,
                        'country' => 'IN',
                        'sunrise' => 1632789740,
                        'sunset' => 1632832867,
                    ],
            
                'timezone' => 19800,
                'id' => 1261481,
                'name' => 'New Delhi',
                'cod' => 200,
                  ];

            return [
              '#theme' => 'weather_template',
              '#weatherData' => $weatherData,
            ];



  }


}
